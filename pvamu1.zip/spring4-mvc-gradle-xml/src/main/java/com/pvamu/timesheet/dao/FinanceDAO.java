package com.pvamu.timesheet.dao;

public interface FinanceDAO {

}
