package com.pvamu.timesheet.dao;

public interface ManagerDAO {

}
